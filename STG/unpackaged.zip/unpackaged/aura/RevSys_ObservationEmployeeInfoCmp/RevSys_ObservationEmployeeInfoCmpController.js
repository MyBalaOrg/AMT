({
    init : function(component, event, helper) {
        helper.createInfo(component);
    },
})