({
	returnPopoverId : function(component) {
		return 'popoverid';
	}
})