({
	doInit : function(component, event, helper) {
	    //get the test list
		helper.getRevSysTestListforObservation(component, event);
    }
})