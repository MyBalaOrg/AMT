({
    populatePropertiesArray : function(component) {
        
    }
 })